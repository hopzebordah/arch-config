DLDIR=$(pwd)
cd ; HOMEDIR=$(pwd)
# sudo rm -r * $HOMEDIR
cd $DLDIR ; sudo mv * $HOMEDIR ; cd

sudo pacman --noconfirm -S git vim thunar i3 termite compton xautolock evince firefox gimp feh mlocate rofi nm-applet vlc cmus zsh jdk8-openjdk wget openssh nm-applet

sudo systemctl enable sshd.service
chsh -s /usr/bin/zsh
sh -c "$(wget https://raw.githubusercontent.com/robbyrussell/oh-my-zsh/master/tools/install.sh -O -)"

sudo rm -r .xinitrc .oh-my-zsh .zshrc .vimrc .Xdefaults .config/i3/config .config/termite/config

mv i3-config config ; mv config .config/i3/
mv termite-config config ; mkdir .config/termite ; mv config .config/termite

rename .. "." ..*

sudo updatedb
